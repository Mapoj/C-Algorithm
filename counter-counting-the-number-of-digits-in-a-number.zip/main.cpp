/******************************************************************************

Program that count the number of digits in a number prompted from the user

*******************************************************************************/
#include <iostream>
using namespace std;


int num;

int main()
{
    cout << "Please enter your numbers: ";
    cin >> num;
    
    if (num == 0)
        cout <<"You have entered 0!";
    else
    {
        if (num < 0)
            num = num * -1;
            
        int counter = 0;
        
        while (num != 0)
        {
            num = num / 10;
            counter++;
        }
        cout <<counter <<" digits"<<endl;
    }

    return 0;
}