/* program that calculates number of days a month has by propting the 
user to enter a year and month*/

#include<iostream>
using namespace std;

double year;
string month;
int MonthSupp=0;

int main ()
{
    cout << "****Days of The Month Calculator****"<<endl;
    cout << "--------------------------------------------"<<endl;
    cout << "Please Enter year: ";
    cin >> year;
    cout << "Please Enter month: ";
    cin >> month;
    cout << "----------------------------------------------------------------"<<endl;
    
    if (month == "Jan" || month == "Mar" || month == "Mey" || month == "Jul" || month == "Aug" || month == "Oct" || month == "Dec")
        MonthSupp = 1;
    else if (month == "Apr" || month == "Jun" || month == "Sept" || month == "Nov")
        MonthSupp = 2;
    else if (month == "Feb")
        MonthSupp = 3;
    else
        MonthSupp = -1;
    
    switch (MonthSupp)
    {
        case 1:
            cout << month << year << " has 31 days";
        break;
        
        case 2:
            cout << month << year << " has 30 days";
        break;
        
        case 3:
            
            bool leapyear1, leapyear2;
            leapyear1 = year / 4;
            leapyear2 = year / 400;
            
            if (leapyear1 == true && leapyear2 == true)
                cout << month << " " << year << " has 29 days and is a leap year";
            else
                cout << month << " "<< year << " has 28 days";
        break;
        
        default:
            cout << "invalid input!";
    }
    
    return 0;
}