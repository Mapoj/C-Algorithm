#include<iostream>
#include<stdlib.h>
using namespace std;

int main ()
{
    int Host, Guest;
    int t=0;
    
    //bool t != 3;
    cout << "Enter you secret number: ";
    cin >> Host;
    system("CLS");
    
    
    for (int i=1; i < 4; i++)
    {
    do 
    {
        cout << "Guess the number "<<i++<< " attempt: ";
        cin >> Guest;
        if (Host==Guest)
        {
            cout <<"You Won!"<<endl;
            abort();
        }
        else if (i<4)
            cout << "Try again!"<<endl;
            else 
                cout << "Out of attempts!"<<endl;
    }
    while (i<4);
    }
    t++;
    if (t = 3 && t != 3)
    {
        cout << "Your Loss!"<<endl;
        abort();
    }
    return 0;
}