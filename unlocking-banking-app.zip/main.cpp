/******************************************************************************

Unlocking banking app. the user is prompted to enter pin with three attempt, if the atterpt
 exceeded the app block the user.

*******************************************************************************/
#include <iostream>
using namespace std;


int main ()
{
    int pin;
    int CorrectPin=2468;
    
    cout << "****Welcome to Banking App****"<<endl;
    cout << "-----------------------------------------------"<<endl;
    
    
    int Attempt =3;
    do 
    {
        cout << "Enter your pin: ";
        cin >> pin;
        Attempt--;
        
        if (pin == CorrectPin)
        {
            cout << "Unloked!";
        }
        else if (Attempt ==0)
        {
            cout << "Access denied! Your account is temporarily bloked";
        }
        else
        {
            cout <<">Try again!\n"<< ">You have "<<Attempt<< " left\n"<<endl;
            system("cls");
        } 
    }
    while (Attempt !=0 && pin!=CorrectPin);
    
    return 0;
}