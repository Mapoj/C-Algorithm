/******************************************************************************

Calculating average grade of student.

*******************************************************************************/
#include <iostream>
#include<math.h>
using namespace std;


int main ()
{
    float Marks, AverageMark=0.00, Sum=0.00;
    int Modules;
    
    cout << "****Average Mark Calculator****"<<endl<< "-----------------------------------" <<endl;
    cout << "Number of Modules: ";
    cin >> Modules;
    
    for (int i=1; i<=Modules;i++)
    {
        do 
        {
            cout << "Module "<<i<<":";
            cin >> Marks;
            
        } while (Marks < 1 || Marks > 100);
        Sum = Sum + Marks;
    }
    AverageMark = Sum / Modules;
    cout << "Average Pass = "<< AverageMark << "%"<<endl;
    
    return 0;
}
    