/* This is my basic calculator using five operations +-*%/*/

#include<iostream>
#include<math.h>
using namespace std;

float value1, value2, CalculatedValue;
int mod1, mod2;
char Oporator;

int main ()
{
	cout << "****Welcome To Pojas Calculator*****"<<endl;
	cout << "-----------------------------------------------"<<endl;
	cin >> value1 >> Oporator >> value2;

	switch (Oporator)
	{
	case '+':
		cout << "value1 + value2 = "<< value1 + value2;
		break;

	case '-':
		cout << "value1 - value2 = "<< value1 - value2;
		break;

	case '*':
		cout << "value1 * value2 = "<< value1 * value2;
		break;

	case '/':
		cout << "value1 / value2 = "<< value1 / value2;
		break;

	case '%':
		mod1 = value1;
		mod2 = value2;
		cout << "value1 % value2 = "<< mod1 % mod2;
		break;

	default:
		cout << "Invalid Inputs";
	}

	return 0;
}